<?php

class PageController extends Controller {

    public function index(){
            
        $limit = $this->route['params']["limit"];
        $afficher = Recette::getListRandom($limit);

        $template = $this->twig->loadTemplate('/Page/index.html.twig');
        echo $template->render(array(
            'afficher' => $afficher
        ));
        
    }
    
    
    public function searchAliment(){
        if(isset($_POST['search']) && $_POST['search'] != ''){
            
            $Aliment = Recette::getSearchAliment($_POST['search'], 10);

            $template =$this->twig->loadTemplate('/Page/search.html.twig');
            echo $template->render(array(
                'aliments'     => $Aliment
            ));
        } else {
            header('Location:/recette');
        }
        
    }

    public function ajaxSearchAliment(){
        $aliment = Recette::getSearchAliment($this->route['params']['search'], 10);
        $resultat = json_encode($aliment);      
        echo $resultat;
    }

    public function conseil(){
        $afficherConseil = Recette::getConseil();

        $template = $this->twig->loadTemplate('/Page/conseil.html.twig');
        echo $template->render(array(
            'conseil' => $afficherConseil
        ));
    }

    public function contact(){
        $messageError = '';
        $friend = '';

        if(isset($_POST['submitContact'])){
            $contact = Recette::setNewContact($_POST);
            if($contact['type'] == 'success'){
                $friend = $_POST['name'];
            } else {
                $messageError = $contact['message'];
            }
        }

        $template = $this->twig->loadTemplate('/Page/contact.html.twig');
        echo $template->render(array(
            'friend'        => $friend,
            'messageError'  => $messageError
        ));
    }

    public function fichePlat(){
        $aliment = Recette::Affiche($this->route['params']['id']);

        $template = $this->twig->loadTemplate('/Page/fiche-aliment.html.twig');
        echo $template->render(array(
            'aliment'   => $aliment
        ));
    }
}
