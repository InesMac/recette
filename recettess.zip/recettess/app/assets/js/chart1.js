<script>

        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ["Cholesterol", "Amidon", "Proteines", "Glucides", "Lipides", "Sucres"],
                datasets: [{
                    label: '# of Votes',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: [
                        'rgb(165, 105, 189)',
                        'rgb(46, 204, 113)',
                        'rgb(241, 148, 138)',
                        'rgb(237, 187, 153)',
                        'rgb(179, 182, 183)',
                        'rgb(217, 136, 128  )'
                    ],
                    borderColor: [
                    'rgb(165, 105, 189)',
                    'rgb(46, 204, 113)',
                    'rgb(241, 148, 138)',
                    'rgb(237, 187, 153)',
                    'rgb(179, 182, 183)',
                    'rgb(217, 136, 128)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
        });
        </script>