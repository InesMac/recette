<?php

class Model  {
}