<?php

Class Recette extends Model{


    public static function Affiche($id) {
        $db = Database::getInstance();
        $sql = "SELECT * FROM plat WHERE id = :id";
        //affichage aliment
        $aliment = $db->prepare($sql);
        $aliment->setFetchMode(PDO::FETCH_ASSOC);
        $aliment->bindValue( ':id', $id, PDO::PARAM_INT); 
        $aliment->execute();
        return $aliment->fetch();
    }

    public static function getListRandom($limit) 
   {
        $db = Database::getInstance();
        $sql = "SELECT aliment, sucres, cholesterol FROM plat ORDER BY RAND() LIMIT :limit";
        $stmt = $db->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindValue(':limit', intval($limit), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
   }

   public static function getConseil() 
   {
        $db = Database::getInstance();
        $sql = "SELECT contenu, auteur FROM citation ORDER BY RAND() limit 1";
        $stmt = $db->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        return $stmt->fetch();
   }
   
   

    public static function getSearchAliment($aliment, $limit = 0){
        $db = Database::getInstance();
        $sql = "SELECT aliment from plat
                where aliment like '%".$aliment."%'";

        if($limit != 0){
            $sql .= ' limit 0, ' .$limit;
        }
        $aliment = $db->prepare($sql);
        $aliment->setFetchMode(PDO::FETCH_ASSOC);
        $aliment->bindValue(':limit', intval($limit), PDO::PARAM_INT);
        $aliment->execute();
        return $aliment->fetchAll();
        
    }

    public static function setNewContact($a_Values){
        $db = Database::getInstance();
        $error = 0;
        $return = array();

        // Vérification des champs obligatoires.        
        if($a_Values['name'] == ''){
            $return['message'] = 'Veuillez saisir votre nom.';
            $return['type'] = 'error';
            $error++;
        }
        if($a_Values['email'] == ''){
            $return['message'] = 'Veuillez saisir votre email.';
            $return['type'] = 'error';
            $error++;
        }

        if($error == 0){
            $stmt = $db->prepare('insert into friend (
                                    name,
                                    message,
                                    email) values (
                                    :name,
                                    :message,
                                    :email)'
            );

            $stmt->bindValue(':name', $a_Values['name'], PDO::PARAM_STR);
            $stmt->bindValue(':message', $a_Values['message'], PDO::PARAM_STR);
            $stmt->bindValue(':email', $a_Values['email'], PDO::PARAM_STR);
            $stmt->execute();

            $return['type'] = 'success';
        }

        return $return;
    }
}

